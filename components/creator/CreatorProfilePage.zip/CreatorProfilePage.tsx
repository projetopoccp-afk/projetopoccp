"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Eye,
  Globe2,
  Loader2,
  Plus,
  PlayCircle,
  Radio,
  Share2,
  ShieldCheck,
  Sparkles,
  UserCheck,
  Trash2,
  UserPlus,
  Users,
  WifiOff,
} from "lucide-react";

import { useLanguage } from "@/contexts/LanguageContext";
import { CreatorCard } from "@/components/cards/CreatorCard";
import { GlowBackground } from "@/components/effects/GlowBackground";
import { ParticleBackground } from "@/components/effects/ParticleBackground";
import { translate } from "@/lib/i18n/translate";
import { getRarityLabel } from "@/lib/rarity";
import { supabase } from "@/lib/supabase/client";
import { addUserXp } from "@/lib/xp/user-xp";
import { updateMissionProgress } from "@/lib/missions/user-missions";
import type {
  Creator,
  CreatorRank,
  CreatorRarity,
  CreatorStatus,
  SocialPlatform,
} from "@/types/creator";

type CreatorProfilePageProps = {
  username: string;
  startInEditMode?: boolean;
};

type CreatorCardRow = {
  rarity: string | null;
  rank: string | null;
  aura: string | null;
  evolution_stage: string | null;
  level: number | null;
  power_score: number | null;
};

type CreatorProfileRow = {
  id: string;
  user_id: string | null;
  username: string;
  nickname: string;
  title: string | null;
  category: string | null;
  status: string | null;
  avatar_url: string | null;
  banner_url: string | null;
  bio: string | null;
  description: string | null;
  tags: unknown;
  is_verified: boolean | null;
  created_at: string | null;
  trending_score: number | null;
  share_count?: number | null;
  creator_cards?: CreatorCardRow[] | CreatorCardRow | null;
};

type SocialLink = {
  platform: string;
  url: string;
};

type CreatorProfileEditDraft = {
  nickname: string;
  title: string;
  category: string;
  avatarUrl: string;
  bannerUrl: string;
  bio: string;
  description: string;
  tagsText: string;
  socialLinksText: string;
};

type AutoClip = {
  id: string;
  title: string;
  platform: "youtube" | "twitch" | "kick" | string;
  url: string;
  thumbnailUrl?: string | null;
  thumbnail_url?: string | null;
  description?: string | null;
  createdAt?: string | null;
  created_at?: string | null;
  viewCount?: number | null;
  view_count?: number | null;
};

type LiveStatus = {
  platform?: string;
  username?: string;
  isLive: boolean;
  title?: string;
  viewerCount?: number;
  gameName?: string;
  startedAt?: string;
  thumbnail?: string;
  url?: string;
  followerCount?: number;
  subscriberCount?: number;
  viewCount?: number;
  videoCount?: number;
  externalCount?: number;
  memberCount?: number;
  onlineMemberCount?: number;
};

type LiveStatusMap = Partial<Record<string, LiveStatus>>;

type CreatorStats = {
  views: number;
  followers: number;
  shares: number;
};

type VisibleYoutubeChannel = {
  url: string;
  originalIndex: number;
  username: string;
};

const PLATFORM_LABELS: Record<string, string> = {
  youtube: "YouTube",
  twitch: "Twitch",
  tiktok: "TikTok",
  kick: "Kick",
  instagram: "Instagram",
  discord: "Discord",
  x: "X",
};

const SOCIAL_PLATFORM_OPTIONS = [
  { value: "twitch", label: "Twitch" },
  { value: "youtube", label: "YouTube" },
  { value: "kick", label: "Kick" },
  { value: "tiktok", label: "TikTok" },
  { value: "instagram", label: "Instagram" },
  { value: "x", label: "X" },
  { value: "discord", label: "Discord" },
  { value: "link", label: "Outro link" },
] as const;

const LIVE_PLATFORMS = ["twitch", "kick"] as const;
const TRUSTED_EXTERNAL_METRIC_PLATFORMS = new Set([
  "youtube",
  "twitch",
  "kick",
]);

const RARITY_SHOWCASE_CYCLE = [
  { rarity: "common" },
  { rarity: "rare" },
  { rarity: "epic" },
  { rarity: "legendary" },
] as const;

const RARITY_SHOWCASE_INTERVAL = 8500;

function normalizeCreatorTags(tags: unknown): string[] {
  if (Array.isArray(tags)) {
    return tags.map((tag) => String(tag).trim()).filter(Boolean);
  }

  if (typeof tags !== "string") return [];

  const trimmed = tags.trim();

  if (!trimmed) return [];

  try {
    const parsed = JSON.parse(trimmed);

    if (Array.isArray(parsed)) {
      return parsed.map((tag) => String(tag).trim()).filter(Boolean);
    }
  } catch {
    // Fallback below for comma-separated values.
  }

  return trimmed
    .replace(/^\[|\]$/g, "")
    .split(",")
    .map((tag) => tag.replace(/"/g, "").trim())
    .filter(Boolean);
}

function getCreatorCard(
  profile: CreatorProfileRow | null,
): CreatorCardRow | null {
  if (!profile?.creator_cards) return null;

  if (Array.isArray(profile.creator_cards)) {
    return profile.creator_cards[0] || null;
  }

  return profile.creator_cards;
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("pt-BR", {
    notation: value >= 10000 ? "compact" : "standard",
    maximumFractionDigits: 1,
  }).format(value);
}

function getPlatformLabel(platform: string) {
  const normalizedPlatform = platform.toLowerCase();

  return PLATFORM_LABELS[normalizedPlatform] || platform;
}

function extractPlatformUsername(platform: string, url: string) {
  const normalizedPlatform = platform.toLowerCase();
  const normalizedUrl = url.trim();

  if (!normalizedUrl) return "";

  try {
    const withProtocol = /^https?:\/\//i.test(normalizedUrl)
      ? normalizedUrl
      : `https://${normalizedUrl}`;

    const parsedUrl = new URL(withProtocol);
    const host = parsedUrl.hostname.replace(/^www\./, "").toLowerCase();

    if (normalizedPlatform === "twitch" && !host.includes("twitch.tv")) {
      return "";
    }

    if (normalizedPlatform === "kick" && !host.includes("kick.com")) {
      return "";
    }

    if (
      normalizedPlatform === "youtube" &&
      !host.includes("youtube.com") &&
      !host.includes("youtu.be")
    ) {
      return "";
    }

    if (normalizedPlatform === "youtube") {
      const pathParts = parsedUrl.pathname.split("/").filter(Boolean);
      const handle = pathParts.find((part) => part.startsWith("@"));

      if (handle) {
        return handle.replace("@", "").trim();
      }

      return pathParts[0]?.replace("@", "").trim() || "";
    }

    if (normalizedPlatform === "discord") {
      const pathParts = parsedUrl.pathname.split("/").filter(Boolean);

      if (host === "discord.gg") {
        return pathParts[0]?.trim() || "";
      }

      if (host.includes("discord.com") || host.includes("discordapp.com")) {
        const inviteIndex = pathParts.findIndex(
          (part) => part.toLowerCase() === "invite",
        );

        if (inviteIndex >= 0) {
          return pathParts[inviteIndex + 1]?.trim() || "";
        }

        return pathParts[0]?.trim() || "";
      }
    }

    const username = parsedUrl.pathname
      .split("/")
      .filter(Boolean)[0]
      ?.replace("@", "")
      .trim();

    return username || "";
  } catch {
    return normalizedUrl
      .replace(/^https?:\/\//i, "")
      .replace(/^www\./i, "")
      .replace(/^twitch\.tv\//i, "")
      .replace(/^kick\.com\//i, "")
      .replace(/^youtube\.com\/@?/i, "")
      .replace(/^youtube\.com\//i, "")
      .replace(/^youtu\.be\//i, "")
      .split(/[/?#]/)[0]
      .replace("@", "")
      .trim();
  }
}

function getPlatformFallbackUrl(platform: string, username: string) {
  const normalizedPlatform = platform.toLowerCase();
  const cleanUsername = username.replace("@", "").trim();

  if (normalizedPlatform === "kick") {
    return `https://kick.com/${cleanUsername}`;
  }

  if (normalizedPlatform === "youtube") {
    return `https://www.youtube.com/${cleanUsername}`;
  }

  if (normalizedPlatform === "instagram") {
    return `https://www.instagram.com/${cleanUsername}`;
  }

  if (normalizedPlatform === "tiktok") {
    return `https://www.tiktok.com/@${cleanUsername}`;
  }

  if (normalizedPlatform === "discord") {
    return `https://discord.gg/${cleanUsername}`;
  }

  return `https://twitch.tv/${cleanUsername}`;
}

function getPlatformLiveStatus(liveStatus: LiveStatusMap, platform: string) {
  return liveStatus[platform.toLowerCase()];
}

function getNormalizedYoutubeChannels(
  channels: string[],
): VisibleYoutubeChannel[] {
  const seen = new Set<string>();

  return channels
    .map((rawUrl, originalIndex) => {
      const url = String(rawUrl || "").trim();
      const username = extractPlatformUsername("youtube", url);

      return {
        url,
        originalIndex,
        username,
      };
    })
    .filter((channel) => channel.url.length > 0 && channel.username.length > 0)
    .filter((channel) => {
      const key = `${channel.username.toLowerCase()}::${channel.url.toLowerCase()}`;

      if (seen.has(key)) return false;

      seen.add(key);
      return true;
    });
}

function getYoutubeChannelFallbackTitle(
  channel: VisibleYoutubeChannel,
  fallbackLabel: string,
) {
  const username = channel.username.replace(/^@/, "").trim();

  if (username.length > 0) {
    return username.startsWith("UC") ? fallbackLabel : `@${username}`;
  }

  return fallbackLabel;
}

function getLiveStatusExternalCount(status: LiveStatus | undefined) {
  return (
    status?.subscriberCount ??
    status?.followerCount ??
    status?.memberCount ??
    status?.externalCount ??
    0
  );
}

function getTrustedLiveStatusExternalCount(
  platform: string,
  status: LiveStatus | undefined,
) {
  const normalizedPlatform = platform.toLowerCase();

  if (!TRUSTED_EXTERNAL_METRIC_PLATFORMS.has(normalizedPlatform)) {
    return 0;
  }

  return getLiveStatusExternalCount(status);
}

function getYoutubeExternalReachFromLiveStatus(liveStatus: LiveStatusMap) {
  return Object.entries(liveStatus)
    .filter(([key]) => key.startsWith("youtube:"))
    .reduce(
      (total, [, status]) => total + getLiveStatusExternalCount(status),
      0,
    );
}

function getCreatorExternalReachFromLiveStatus(liveStatus: LiveStatusMap) {
  const twitchStatus = getPlatformLiveStatus(liveStatus, "twitch");
  const kickStatus = getPlatformLiveStatus(liveStatus, "kick");
  const youtubeSubscribers = getYoutubeExternalReachFromLiveStatus(liveStatus);

  const twitchFollowers = getTrustedLiveStatusExternalCount(
    "twitch",
    twitchStatus,
  );
  const kickFollowers = getTrustedLiveStatusExternalCount("kick", kickStatus);

  return twitchFollowers + kickFollowers + youtubeSubscribers;
}

function getSocialUrl(socialLinks: SocialLink[], platform: string) {
  return (
    socialLinks.find((social) => social.platform.toLowerCase() === platform)
      ?.url || ""
  );
}

function normalizeCreatorStatus(
  status: string | null | undefined,
): CreatorStatus {
  const normalizedStatus = String(status || "offline").toLowerCase();

  if (
    normalizedStatus === "online" ||
    normalizedStatus === "offline" ||
    normalizedStatus === "live" ||
    normalizedStatus === "trending" ||
    normalizedStatus === "event"
  ) {
    return normalizedStatus;
  }

  return "offline";
}

function normalizeCreatorRarity(
  rarity: string | null | undefined,
): CreatorRarity {
  const normalizedRarity = String(rarity || "common").toLowerCase();

  if (
    normalizedRarity === "common" ||
    normalizedRarity === "rare" ||
    normalizedRarity === "epic" ||
    normalizedRarity === "legendary" ||
    normalizedRarity === "mythic"
  ) {
    return normalizedRarity;
  }

  return "common";
}

function normalizeCreatorRank(rank: string | null | undefined): CreatorRank {
  const normalizedRank = String(rank || "Bronze");

  if (
    normalizedRank === "Bronze" ||
    normalizedRank === "Silver" ||
    normalizedRank === "Gold" ||
    normalizedRank === "Platinum" ||
    normalizedRank === "Ascendant"
  ) {
    return normalizedRank;
  }

  return "Bronze";
}

function isLikelyImageUrl(url: string) {
  const normalizedUrl = url.split("?")[0]?.toLowerCase() || "";

  return /\.(apng|avif|gif|jpg|jpeg|png|svg|webp)$/.test(normalizedUrl);
}

function isLikelyDirectMediaUrl(url: string) {
  const normalizedUrl = url.split("?")[0]?.toLowerCase() || "";

  return /\.(m3u8|mp4|m4v|mov|webm|mkv|avi|ts|m4a|mp3|wav|ogg)$/.test(
    normalizedUrl,
  );
}

function getSafeClipUrl(clip: AutoClip, socialLinks: SocialLink[]) {
  const rawUrl = (clip.url || "").trim();

  if (rawUrl && !isLikelyImageUrl(rawUrl) && !isLikelyDirectMediaUrl(rawUrl)) {
    return rawUrl;
  }

  const platformUrl = getSocialUrl(
    socialLinks,
    String(clip.platform || "").toLowerCase() as SocialPlatform,
  );

  return platformUrl || "#";
}

function createProfileEditDraft(
  profile: CreatorProfileRow,
  socialLinks: SocialLink[],
): CreatorProfileEditDraft {
  return {
    nickname: profile.nickname || "",
    title: profile.title || "",
    category: profile.category || "",
    avatarUrl: profile.avatar_url || "",
    bannerUrl: profile.banner_url || "",
    bio: profile.bio || "",
    description: profile.description || "",
    tagsText: normalizeCreatorTags(profile.tags).join(", "),
    socialLinksText: socialLinks
      .map((social) => `${social.platform}: ${social.url}`)
      .join("\n"),
  };
}

function parseEditTags(tagsText: string) {
  return tagsText
    .split(/[,\n]/)
    .map((tag) => tag.trim().replace(/^#/, ""))
    .filter(Boolean);
}

function parseEditSocialLinks(socialLinksText: string): SocialLink[] {
  return socialLinksText
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const separatorIndex = line.indexOf(":");

      if (separatorIndex === -1) {
        return {
          platform: "link",
          url: line,
        };
      }

      const platform = line.slice(0, separatorIndex).trim();
      const url = line.slice(separatorIndex + 1).trim();

      return {
        platform: platform || "link",
        url,
      };
    })
    .filter((social) => Boolean(social.url));
}

function getEditSocialLinkRows(socialLinksText: string): SocialLink[] {
  const parsedLinks = parseEditSocialLinks(socialLinksText);

  return parsedLinks.length > 0
    ? parsedLinks
    : [{ platform: "twitch", url: "" }];
}

function serializeEditSocialLinks(socialLinks: SocialLink[]) {
  return socialLinks
    .map((social) => {
      const platform = social.platform.trim() || "link";
      const url = social.url.trim();

      return url ? `${platform}: ${url}` : "";
    })
    .filter(Boolean)
    .join("\n");
}

function normalizeCreatorSocials(socialLinks: SocialLink[]) {
  const allowedPlatforms = new Set<SocialPlatform>([
    "twitch",
    "youtube",
    "tiktok",
    "kick",
    "instagram",
    "discord",
    "x",
  ]);

  return socialLinks
    .map((social) => ({
      platform: social.platform.toLowerCase(),
      url: social.url,
    }))
    .filter(
      (social): social is { platform: SocialPlatform; url: string } =>
        allowedPlatforms.has(social.platform as SocialPlatform) &&
        social.url.trim().length > 0,
    );
}

type NotificationType =
  | "card_unlocked"
  | "level_up"
  | "follow_creator"
  | "share_profile"
  | "generic";

async function createUserNotification({
  userId,
  type,
  title,
  message,
  metadata = {},
}: {
  userId: string;
  type: NotificationType;
  title: string;
  message?: string;
  metadata?: Record<string, unknown>;
}) {
  const { error } = await supabase.from("user_notifications").insert({
    user_id: userId,
    type,
    title,
    message,
    metadata,
  });

  if (error) {
    console.error("Erro ao criar notificação:", error);
  }
}

async function getCurrentUserLevel(userId: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("level")
    .eq("id", userId)
    .maybeSingle();

  if (error) {
    console.error("Erro ao buscar level atual:", error);
  }

  return data?.level || 1;
}

async function hasXpEvent(
  userId: string,
  eventType: string,
  metadata: Record<string, unknown>,
) {
  const { data, error } = await supabase
    .from("user_xp_events")
    .select("id")
    .eq("user_id", userId)
    .eq("event_type", eventType)
    .contains("metadata", metadata)
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error("Erro ao verificar evento de XP:", error);
    return false;
  }

  return Boolean(data);
}

async function addXpAndNotifyLevelUp({
  userId,
  eventType,
  metadata,
}: {
  userId: string;
  eventType: Parameters<typeof addUserXp>[0];
  metadata: Record<string, unknown>;
}) {
  const previousLevel = await getCurrentUserLevel(userId);
  const result = await addUserXp(eventType, metadata);

  if (result?.new_level && result.new_level > previousLevel) {
    await createUserNotification({
      userId,
      type: "level_up",
      title: `Você chegou ao nível ${result.new_level}!`,
      message: "Seu perfil evoluiu no Cardpoc.",
      metadata: {
        ...metadata,
        previous_level: previousLevel,
        new_level: result.new_level,
        new_xp: result.new_xp,
      },
    });
  }

  return result;
}

export function CreatorProfilePage({
  username,
  startInEditMode = false,
}: CreatorProfilePageProps) {
  const { t } = useLanguage();
  const router = useRouter();

  const [profile, setProfile] = useState<CreatorProfileRow | null>(null);
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>([]);
  const [clips, setClips] = useState<AutoClip[]>([]);
  const [clipsLoading, setClipsLoading] = useState(false);
  const [stats, setStats] = useState<CreatorStats>({
    views: 0,
    followers: 0,
    shares: 0,
  });
  const [liveStatus, setLiveStatus] = useState<LiveStatusMap>({});
  const [liveStatusLoading, setLiveStatusLoading] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserIsAdmin, setCurrentUserIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(startInEditMode);
  const [editDraft, setEditDraft] = useState<CreatorProfileEditDraft | null>(
    null,
  );
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [profileSaveError, setProfileSaveError] = useState<string | null>(null);
  const [youtubeChannelsOpen, setYoutubeChannelsOpen] = useState(false);
  const [livePlatformsOpen, setLivePlatformsOpen] = useState(false);
  const [profileLinkCopied, setProfileLinkCopied] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followLoading, setFollowLoading] = useState(false);
  const [showcaseRarityIndex, setShowcaseRarityIndex] = useState(0);

  const decodedUsername = useMemo(() => {
    return decodeURIComponent(username || "")
      .replace("@", "")
      .trim();
  }, [username]);

  const creatorPublicPath = useMemo(() => {
    const targetUsername = profile?.username || decodedUsername || username;

    return `/creator/${encodeURIComponent(targetUsername)}`;
  }, [decodedUsername, profile?.username, username]);

  useEffect(() => {
    const intervalId = window.setInterval(() => {
      setShowcaseRarityIndex(
        (current) => (current + 1) % RARITY_SHOWCASE_CYCLE.length,
      );
    }, RARITY_SHOWCASE_INTERVAL);

    return () => {
      window.clearInterval(intervalId);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function loadCurrentUser() {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        if (!cancelled) {
          setCurrentUserId(null);
          setCurrentUserIsAdmin(false);
        }

        return;
      }

      const { data: accountProfile } = await supabase
        .from("profiles")
        .select("is_admin")
        .eq("id", user.id)
        .maybeSingle();

      if (!cancelled) {
        setCurrentUserId(user.id);
        setCurrentUserIsAdmin(Boolean(accountProfile?.is_admin));
      }
    }

    loadCurrentUser();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function loadCreatorProfile() {
      setLoading(true);

      const { data, error } = await supabase
        .from("creator_profiles")
        .select(
          `
          id,
          user_id,
          username,
          nickname,
          title,
          category,
          status,
          avatar_url,
          banner_url,
          bio,
          description,
          tags,
          is_verified,
          created_at,
          trending_score,
          share_count,
          creator_cards (
            rarity,
            rank,
            aura,
            evolution_stage,
            level,
            power_score
          )
        `,
        )
        .eq("is_public", true)
        .ilike("username", decodedUsername)
        .maybeSingle();

      if (cancelled) return;

      if (error || !data) {
        setProfile(null);
        setSocialLinks([]);
        setClips([]);
        setLiveStatus({});
        setStats({
          views: 0,
          followers: 0,
          shares: 0,
        });
        setLoading(false);
        return;
      }

      const typedProfile = data as CreatorProfileRow;

      setProfile(typedProfile);

      const [
        { data: socialData },
        { count: viewCount },
        { count: followerCount },
      ] = await Promise.all([
        supabase
          .from("creator_social_links")
          .select("platform, url")
          .eq("creator_id", typedProfile.id)
          .order("platform", { ascending: true }),
        supabase
          .from("creator_views")
          .select("id", { count: "exact", head: true })
          .eq("creator_id", typedProfile.id),
        supabase
          .from("creator_followers")
          .select("id", { count: "exact", head: true })
          .eq("creator_id", typedProfile.id),
      ]);

      if (cancelled) return;

      setSocialLinks((socialData || []) as SocialLink[]);
      setStats({
        views: viewCount || 0,
        followers: followerCount || 0,
        shares: typedProfile.share_count || 0,
      });
      setLoading(false);
    }

    if (decodedUsername) {
      loadCreatorProfile();
    } else {
      setProfile(null);
      setLoading(false);
    }

    return () => {
      cancelled = true;
    };
  }, [decodedUsername]);

  useEffect(() => {
    if (!profile) {
      setEditDraft(null);
      return;
    }

    setEditDraft(createProfileEditDraft(profile, socialLinks));
  }, [profile, socialLinks]);

  useEffect(() => {
    let cancelled = false;

    async function loadFollowState() {
      if (!profile?.id || !currentUserId) {
        if (!cancelled) {
          setIsFollowing(false);
        }
        return;
      }

      const { data } = await supabase
        .from("creator_followers")
        .select("id")
        .eq("creator_id", profile.id)
        .eq("user_id", currentUserId)
        .maybeSingle();

      if (!cancelled) {
        setIsFollowing(Boolean(data));
      }
    }

    loadFollowState();

    return () => {
      cancelled = true;
    };
  }, [profile?.id, currentUserId]);

  useEffect(() => {
    if (!profile) {
      setLiveStatus({});
      return;
    }

    const youtubeChannels = socialLinks
      .filter((social) => social.platform.toLowerCase() === "youtube")
      .map((social) => social.url);

    const targets: Array<{
      platform: "twitch" | "kick" | "youtube";
      username: string;
      index?: number;
    }> = [
      ...socialLinks
        .map((social) => {
          const platform = social.platform.toLowerCase();

          if (platform !== "twitch" && platform !== "kick") {
            return null;
          }

          const platformUsername = extractPlatformUsername(
            platform,
            social.url,
          );

          return {
            platform,
            username: platformUsername,
          };
        })
        .filter(
          (
            target,
          ): target is {
            platform: "twitch" | "kick";
            username: string;
          } => Boolean(target && target.username.length > 0),
        ),
      ...getNormalizedYoutubeChannels(youtubeChannels).map((channel) => ({
        platform: "youtube" as const,
        username: channel.username,
        index: channel.originalIndex,
      })),
    ];

    if (targets.length === 0) {
      setLiveStatus({});
      return;
    }

    let cancelled = false;

    async function loadLiveStatuses() {
      setLiveStatusLoading(true);

      try {
        const results = await Promise.all(
          targets.map(async ({ platform, username: targetUsername, index }) => {
            try {
              const response = await fetch(
                `/api/live-status?platform=${platform}&username=${encodeURIComponent(
                  targetUsername,
                )}`,
              );

              if (!response.ok) {
                throw new Error(`Unable to load ${platform} live status.`);
              }

              const data: LiveStatus = await response.json();

              return {
                platform,
                index,
                status: {
                  ...data,
                  url:
                    data.url ||
                    getPlatformFallbackUrl(platform, targetUsername),
                },
              };
            } catch {
              return {
                platform,
                index,
                status: {
                  platform,
                  username: targetUsername,
                  isLive: false,
                  url: getPlatformFallbackUrl(platform, targetUsername),
                },
              };
            }
          }),
        );

        if (!cancelled) {
          setLiveStatus(
            results.reduce<LiveStatusMap>((accumulator, result) => {
              if (result.platform === "youtube") {
                accumulator[`youtube:${result.index ?? 0}`] = result.status;

                const currentYoutube = accumulator.youtube;
                const currentSubscriberCount =
                  currentYoutube?.subscriberCount ??
                  currentYoutube?.externalCount ??
                  0;
                const nextSubscriberCount =
                  result.status.subscriberCount ??
                  result.status.externalCount ??
                  0;

                accumulator.youtube =
                  nextSubscriberCount >= currentSubscriberCount
                    ? result.status
                    : currentYoutube || result.status;

                return accumulator;
              }

              accumulator[result.platform] = result.status;
              return accumulator;
            }, {}),
          );
        }
      } finally {
        if (!cancelled) {
          setLiveStatusLoading(false);
        }
      }
    }

    loadLiveStatuses();

    return () => {
      cancelled = true;
    };
  }, [profile, socialLinks]);

  useEffect(() => {
    if (!profile) {
      setClips([]);
      return;
    }

    const twitchUsername = extractPlatformUsername(
      "twitch",
      getSocialUrl(socialLinks, "twitch"),
    );
    const kickUsername = extractPlatformUsername(
      "kick",
      getSocialUrl(socialLinks, "kick"),
    );
    const youtubeUrls = socialLinks
      .filter((social) => social.platform.toLowerCase() === "youtube")
      .map((social) => social.url)
      .filter(Boolean);

    if (!twitchUsername && !kickUsername && youtubeUrls.length === 0) {
      setClips([]);
      return;
    }

    const params = new URLSearchParams();

    if (twitchUsername) {
      params.set("twitch", twitchUsername);
    }

    if (kickUsername) {
      params.set("kick", kickUsername);
    }

    youtubeUrls.forEach((url) => {
      params.append("youtube", url);
    });

    let cancelled = false;

    async function loadAutoClips() {
      setClipsLoading(true);

      try {
        const response = await fetch(`/api/creator-clips?${params.toString()}`);

        if (!response.ok) {
          throw new Error("Unable to load creator clips.");
        }

        const data = await response.json();

        if (!cancelled) {
          setClips(Array.isArray(data?.clips) ? data.clips : []);
        }
      } catch {
        if (!cancelled) {
          setClips([]);
        }
      } finally {
        if (!cancelled) {
          setClipsLoading(false);
        }
      }
    }

    loadAutoClips();

    return () => {
      cancelled = true;
    };
  }, [profile, socialLinks]);

  const card = getCreatorCard(profile);
  const nickname =
    profile?.nickname ||
    decodedUsername ||
    translate(t, "creatorProfileFallbackName", "Criador Cardpoc");
  const title =
    profile?.title ||
    translate(t, "creatorProfileDefaultTitle", "Criador de conteúdo");
  const category =
    profile?.category ||
    translate(t, "creatorProfileDefaultCategory", "Criador");
  const bio =
    profile?.bio ||
    translate(
      t,
      "creatorProfileDefaultBio",
      "Perfil público de criador aprovado no Cardpoc.",
    );
  const description =
    profile?.description ||
    translate(
      t,
      "creatorProfileDefaultDescription",
      "Acompanhe cartas colecionáveis, presença digital, redes sociais e momentos em destaque deste criador no Cardpoc.",
    );
  const rarity = card?.rarity || "common";
  const tags = normalizeCreatorTags(profile?.tags);
  const visibleTags = tags;
  const externalReach = getCreatorExternalReachFromLiveStatus(liveStatus);
  const twitchStatus = getPlatformLiveStatus(liveStatus, "twitch");
  const kickStatus = getPlatformLiveStatus(liveStatus, "kick");
  const youtubeStatus = getPlatformLiveStatus(liveStatus, "youtube");
  const instagramStatus = getPlatformLiveStatus(liveStatus, "instagram");
  const tiktokStatus = getPlatformLiveStatus(liveStatus, "tiktok");
  const discordStatus = getPlatformLiveStatus(liveStatus, "discord");
  const visibleYoutubeChannels = getNormalizedYoutubeChannels(
    socialLinks
      .filter((social) => social.platform.toLowerCase() === "youtube")
      .map((social) => social.url),
  );
  const youtubeExternalReach =
    getYoutubeExternalReachFromLiveStatus(liveStatus);
  const youtubeChannelItems = visibleYoutubeChannels.map((channel, index) => {
    const channelStatus = getPlatformLiveStatus(
      liveStatus,
      `youtube:${channel.originalIndex}`,
    );

    const fallbackTitle = getYoutubeChannelFallbackTitle(
      channel,
      `${translate(t, "creatorPopupYoutubeChannelFallback", "Canal")} ${index + 1}`,
    );

    return {
      url: channelStatus?.url || channel.url,
      title: channelStatus?.title || fallbackTitle,
      thumbnail: channelStatus?.thumbnail,
      subscriberCount:
        channelStatus?.subscriberCount ?? channelStatus?.externalCount ?? 0,
    };
  });
  const isLive = Boolean(twitchStatus?.isLive || kickStatus?.isLive);
  const isOwner = Boolean(
    profile?.user_id && currentUserId === profile.user_id,
  );
  const canManageProfile = Boolean(isOwner || currentUserIsAdmin);
  const profileUrl = `/creator/${encodeURIComponent(
    profile?.username || decodedUsername,
  )}`;

  const groupedClips = clips.reduce<Record<string, AutoClip[]>>(
    (accumulator, clip) => {
      const platform = String(clip.platform || "outros").toLowerCase();

      if (!accumulator[platform]) {
        accumulator[platform] = [];
      }

      accumulator[platform].push(clip);
      return accumulator;
    },
    {},
  );

  const clipPlatformSections = (
    Object.entries(groupedClips) as Array<[string, AutoClip[]]>
  ).sort(([platformA], [platformB]) => {
    const order = ["youtube", "twitch", "kick", "tiktok", "instagram"];
    const indexA = order.indexOf(platformA);
    const indexB = order.indexOf(platformB);

    return (indexA === -1 ? 99 : indexA) - (indexB === -1 ? 99 : indexB);
  });

  async function refreshCreatorProfile() {
    if (!decodedUsername) return;

    const { data, error } = await supabase
      .from("creator_profiles")
      .select(
        `
        id,
        user_id,
        username,
        nickname,
        title,
        category,
        status,
        avatar_url,
        banner_url,
        bio,
        description,
        tags,
        is_verified,
        created_at,
        trending_score,
        share_count,
        creator_cards (
          rarity,
          rank,
          aura,
          evolution_stage,
          level,
          power_score
        )
      `,
      )
      .eq("is_public", true)
      .ilike("username", decodedUsername)
      .maybeSingle();

    if (error || !data) return;

    const typedProfile = data as CreatorProfileRow;
    setProfile(typedProfile);

    const [
      { data: socialData },
      { count: viewCount },
      { count: followerCount },
    ] = await Promise.all([
      supabase
        .from("creator_social_links")
        .select("platform, url")
        .eq("creator_id", typedProfile.id)
        .order("platform", { ascending: true }),
      supabase
        .from("creator_views")
        .select("id", { count: "exact", head: true })
        .eq("creator_id", typedProfile.id),
      supabase
        .from("creator_followers")
        .select("id", { count: "exact", head: true })
        .eq("creator_id", typedProfile.id),
    ]);

    setSocialLinks((socialData || []) as SocialLink[]);
    setStats({
      views: viewCount || 0,
      followers: followerCount || 0,
      shares: typedProfile.share_count || 0,
    });
  }

  function handleEditDraftChange(
    field: keyof CreatorProfileEditDraft,
    value: string,
  ) {
    setEditDraft((current) =>
      current
        ? {
            ...current,
            [field]: value,
          }
        : current,
    );
    setProfileSaveError(null);
  }

  function handleEditSocialLinkChange(
    index: number,
    field: keyof SocialLink,
    value: string,
  ) {
    setEditDraft((current) => {
      if (!current) return current;

      const rows = getEditSocialLinkRows(current.socialLinksText);
      const nextRows = rows.map((social, socialIndex) =>
        socialIndex === index
          ? {
              ...social,
              [field]: value,
            }
          : social,
      );

      return {
        ...current,
        socialLinksText: serializeEditSocialLinks(nextRows),
      };
    });
    setProfileSaveError(null);
  }

  function handleAddEditSocialLink() {
    setEditDraft((current) => {
      if (!current) return current;

      const rows = getEditSocialLinkRows(current.socialLinksText);

      return {
        ...current,
        socialLinksText: serializeEditSocialLinks([
          ...rows,
          { platform: "youtube", url: "" },
        ]),
      };
    });
    setProfileSaveError(null);
  }

  function handleRemoveEditSocialLink(index: number) {
    setEditDraft((current) => {
      if (!current) return current;

      const rows = getEditSocialLinkRows(current.socialLinksText);
      const nextRows = rows.filter((_, socialIndex) => socialIndex !== index);

      return {
        ...current,
        socialLinksText: serializeEditSocialLinks(nextRows),
      };
    });
    setProfileSaveError(null);
  }

  function handleCancelEditMode() {
    if (profile) {
      setEditDraft(createProfileEditDraft(profile, socialLinks));
    }

    setProfileSaveError(null);
    setIsEditing(false);

    if (startInEditMode) {
      router.replace(creatorPublicPath);
    }
  }

  async function handleSaveProfileEdit() {
    if (!profile || !editDraft || !canManageProfile) return;

    setIsSavingProfile(true);
    setProfileSaveError(null);

    const nextTags = parseEditTags(editDraft.tagsText);
    const nextSocialLinks = parseEditSocialLinks(editDraft.socialLinksText);

    const { error } = await supabase
      .from("creator_profiles")
      .update({
        nickname: editDraft.nickname.trim() || profile.nickname,
        title: editDraft.title.trim() || null,
        category: editDraft.category.trim() || null,
        avatar_url: editDraft.avatarUrl.trim() || null,
        banner_url: editDraft.bannerUrl.trim() || null,
        bio: editDraft.bio.trim() || null,
        description: editDraft.description.trim() || null,
        tags: nextTags,
      })
      .eq("id", profile.id);

    if (error) {
      setIsSavingProfile(false);
      setProfileSaveError(error.message);
      return;
    }

    const { error: deleteSocialLinksError } = await supabase
      .from("creator_social_links")
      .delete()
      .eq("creator_id", profile.id);

    if (deleteSocialLinksError) {
      setIsSavingProfile(false);
      setProfileSaveError(deleteSocialLinksError.message);
      return;
    }

    if (nextSocialLinks.length > 0) {
      const { error: insertSocialLinksError } = await supabase
        .from("creator_social_links")
        .insert(
          nextSocialLinks.map((social) => ({
            creator_id: profile.id,
            platform: social.platform,
            url: social.url,
          })),
        );

      if (insertSocialLinksError) {
        setIsSavingProfile(false);
        setProfileSaveError(insertSocialLinksError.message);
        return;
      }
    }

    setProfile((current) =>
      current
        ? {
            ...current,
            nickname: editDraft.nickname.trim() || current.nickname,
            title: editDraft.title.trim() || null,
            category: editDraft.category.trim() || null,
            avatar_url: editDraft.avatarUrl.trim() || null,
            banner_url: editDraft.bannerUrl.trim() || null,
            bio: editDraft.bio.trim() || null,
            description: editDraft.description.trim() || null,
            tags: nextTags,
          }
        : current,
    );
    setSocialLinks(nextSocialLinks);
    setIsSavingProfile(false);
    setIsEditing(false);

    await refreshCreatorProfile();

    if (startInEditMode) {
      router.replace(creatorPublicPath);
    }
  }

  async function handleFollow() {
    if (!profile) return;

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      alert(
        translate(
          t,
          "creatorPopupLoginToFollow",
          "Faça login para seguir este creator.",
        ),
      );
      return;
    }

    setFollowLoading(true);

    try {
      if (isFollowing) {
        const { error } = await supabase
          .from("creator_followers")
          .delete()
          .eq("creator_id", profile.id)
          .eq("user_id", user.id);

        if (error) {
          alert(error.message);
          return;
        }

        setIsFollowing(false);
        setStats((current) => ({
          ...current,
          followers: Math.max(0, current.followers - 1),
        }));
        return;
      }

      const { error } = await supabase.from("creator_followers").insert({
        creator_id: profile.id,
        user_id: user.id,
      });

      if (error) {
        alert(error.message);
        return;
      }

      setIsFollowing(true);
      setStats((current) => ({
        ...current,
        followers: current.followers + 1,
      }));

      const metadata = {
        creator_id: profile.id,
        creator_username: profile.username,
        creator_nickname: nickname,
      };

      const followAlreadyRewarded = await hasXpEvent(
        user.id,
        "follow_creator",
        { creator_id: profile.id },
      );

      if (!followAlreadyRewarded) {
        await addXpAndNotifyLevelUp({
          userId: user.id,
          eventType: "follow_creator",
          metadata,
        });

        await createUserNotification({
          userId: user.id,
          type: "follow_creator",
          title: `${translate(
            t,
            "creatorPopupFollowNotificationPrefix",
            "Você seguiu",
          )} ${nickname}`,
          message: translate(
            t,
            "creatorPopupFollowXpMessage",
            "Você ganhou XP por seguir um creator.",
          ),
          metadata,
        });
      }

      await updateMissionProgress("follow_creator", 1, metadata);

      const { data: existingCard } = await supabase
        .from("user_cards")
        .select("id")
        .eq("creator_id", profile.id)
        .eq("user_id", user.id)
        .maybeSingle();

      if (!existingCard) {
        const { data: newCard, error: cardError } = await supabase
          .from("user_cards")
          .insert({
            creator_id: profile.id,
            user_id: user.id,
            rarity: "common",
            source: "follow",
          })
          .select("id, rarity, source, obtained_at")
          .single();

        if (cardError) {
          console.error("Erro ao criar carta do usuário:", cardError);
        } else {
          await addXpAndNotifyLevelUp({
            userId: user.id,
            eventType: "collect_common_card",
            metadata: {
              creator_id: profile.id,
              creator_username: profile.username,
              creator_nickname: nickname,
              card_id: newCard?.id,
              rarity: newCard?.rarity,
              source: newCard?.source,
            },
          });

          await createUserNotification({
            userId: user.id,
            type: "card_unlocked",
            title: `${translate(
              t,
              "creatorPopupCardUnlockedNotificationTitle",
              "Carta desbloqueada:",
            )} ${nickname}`,
            message: translate(
              t,
              "creatorPopupCardUnlockedByFollow",
              "Você ganhou uma carta comum por seguir este creator.",
            ),
            metadata: {
              creator_id: profile.id,
              creator_username: profile.username,
              creator_nickname: nickname,
              card_id: newCard?.id,
              rarity: newCard?.rarity,
              source: newCard?.source,
            },
          });

          await updateMissionProgress("collect_card", 1, {
            creator_id: profile.id,
            creator_username: profile.username,
            creator_nickname: nickname,
            rarity: newCard?.rarity,
            source: newCard?.source,
          });
        }
      }
    } finally {
      setFollowLoading(false);
    }
  }

  async function copyProfileLink() {
    const baseUrl =
      typeof window !== "undefined"
        ? window.location.origin
        : "https://www.cardpoc.com";
    const fullProfileUrl = `${baseUrl}${profileUrl}`;

    try {
      await navigator.clipboard.writeText(fullProfileUrl);
      setProfileLinkCopied(true);
      window.setTimeout(() => setProfileLinkCopied(false), 1800);
    } catch {
      window.open(profileUrl, "_blank", "noopener,noreferrer");
    }
  }

  const platformCounters = [
    {
      key: "youtube",
      label:
        visibleYoutubeChannels.length > 1
          ? `YouTube (${visibleYoutubeChannels.length})`
          : "YouTube",
      value: youtubeExternalReach,
      suffix: translate(t, "creatorProfileSubscribers", "inscritos"),
      url: youtubeStatus?.url || getSocialUrl(socialLinks, "youtube"),
      isLive: false,
    },
    {
      key: "twitch",
      label: "Twitch",
      value: getTrustedLiveStatusExternalCount("twitch", twitchStatus),
      suffix: translate(t, "creatorProfileFollowersShort", "seguidores"),
      url: twitchStatus?.url || getSocialUrl(socialLinks, "twitch"),
      isLive: Boolean(twitchStatus?.isLive),
    },
    {
      key: "kick",
      label: "Kick",
      value: getTrustedLiveStatusExternalCount("kick", kickStatus),
      suffix: translate(t, "creatorProfileFollowersShort", "seguidores"),
      url: kickStatus?.url || getSocialUrl(socialLinks, "kick"),
      isLive: Boolean(kickStatus?.isLive),
    },
    {
      key: "instagram",
      label: "Instagram",
      value: 0,
      suffix: translate(t, "creatorProfileFollowersShort", "seguidores"),
      url: instagramStatus?.url || getSocialUrl(socialLinks, "instagram"),
      isLive: false,
    },
    {
      key: "tiktok",
      label: "TikTok",
      value: 0,
      suffix: translate(t, "creatorProfileFollowersShort", "seguidores"),
      url: tiktokStatus?.url || getSocialUrl(socialLinks, "tiktok"),
      isLive: false,
    },
    {
      key: "discord",
      label: "Discord",
      value: 0,
      suffix: "membros",
      url: discordStatus?.url || getSocialUrl(socialLinks, "discord"),
      isLive: false,
    },
  ].filter((item) => item.value > 0 || item.isLive);

  const livePlatformItems = [
    {
      key: "twitch",
      label: "Twitch",
      status: twitchStatus,
      fallbackUrl: getSocialUrl(socialLinks, "twitch"),
    },
    {
      key: "kick",
      label: "Kick",
      status: kickStatus,
      fallbackUrl: getSocialUrl(socialLinks, "kick"),
    },
  ].filter((item) => item.status?.isLive);

  const heroLiveStatus = livePlatformItems[0]?.status || null;

  const creatorForPopup: Creator | null = profile
    ? {
        id: profile.id,
        ownerId: profile.user_id || undefined,
        username: profile.username,
        nickname,
        title,
        faction: "",
        category,
        mainPlatform: "youtube",
        status: normalizeCreatorStatus(profile.status),
        avatarUrl: profile.avatar_url || "",
        bannerUrl: profile.banner_url || "",
        bio,
        description,
        tags,
        rank: normalizeCreatorRank(card?.rank),
        rarity: normalizeCreatorRarity(rarity),
        aura: card?.aura || "Origin Aura",
        evolutionStage: card?.evolution_stage || "Stage 1 — Rising Creator",
        powerScore: card?.power_score || 0,
        collectedBy: 0,
        level: card?.level || 1,
        followers: stats.followers,
        likes: 0,
        views: stats.views,
        socials: normalizeCreatorSocials(socialLinks),
        traits: [],
        featuredMoment: {
          title: "",
          description: "",
        },
        achievements: [],
      }
    : null;

  const showcaseRarity =
    RARITY_SHOWCASE_CYCLE[showcaseRarityIndex]?.rarity || rarity;
  const creatorForCard: Creator | null = creatorForPopup
    ? {
        ...creatorForPopup,
        rarity: normalizeCreatorRarity(showcaseRarity),
      }
    : null;
  const isProfileClaimable = !profile?.user_id;

  if (loading) {
    return null;
  }

  if (!profile) {
    return (
      <main className="min-h-screen bg-[#020617] px-6 py-10 text-white">
        <div className="mx-auto flex min-h-[70vh] max-w-3xl flex-col items-center justify-center text-center">
          <div className="rounded-full border border-cyan-300/20 bg-cyan-300/10 p-4 text-cyan-100">
            <Sparkles className="h-7 w-7" />
          </div>

          <h1 className="mt-6 text-3xl font-black tracking-tight md:text-5xl">
            {translate(
              t,
              "creatorProfileNotFoundTitle",
              "Criador não encontrado",
            )}
          </h1>

          <p className="mt-4 max-w-xl text-sm leading-7 text-white/60 md:text-base">
            {translate(
              t,
              "creatorProfileNotFoundDescription",
              "Este perfil ainda não está público ou não existe no Cardpoc.",
            )}
          </p>

          <Link
            href="/"
            className="mt-8 inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/10 px-5 py-3 text-sm font-bold text-cyan-100 transition hover:bg-cyan-300/20"
          >
            <ArrowLeft className="h-4 w-4" />
            {translate(t, "creatorProfileBackHome", "Voltar para o Cardpoc")}
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-black text-white">
      <GlowBackground />
      <ParticleBackground />

      <div className="pointer-events-none absolute inset-0 z-0 bg-[linear-gradient(rgba(34,211,238,0.035)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.035)_1px,transparent_1px)] bg-[size:44px_44px] [mask-image:radial-gradient(circle_at_center,black,transparent_78%)]" />
      <div className="pointer-events-none absolute left-1/2 top-28 z-0 h-72 w-72 -translate-x-1/2 rounded-full bg-cyan-400/10 blur-[90px]" />
      <div className="pointer-events-none absolute bottom-24 right-10 z-0 h-80 w-80 rounded-full bg-fuchsia-500/10 blur-[100px]" />

      <div className="relative z-10 mx-auto max-w-7xl px-6 pb-16 pt-8">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs font-bold uppercase tracking-[0.22em] text-white/65 backdrop-blur transition hover:border-cyan-300/30 hover:text-cyan-100"
          >
            <ArrowLeft className="h-4 w-4" />
            {translate(
              t,
              "creatorProfileExploreCreators",
              "Explorar criadores",
            )}
          </Link>

          {canManageProfile && !isEditing ? (
            <Link
              href={`/creator/${encodeURIComponent(profile.username)}/dashboard`}
              className="inline-flex items-center gap-2 rounded-full border border-fuchsia-300/20 bg-fuchsia-300/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.22em] text-fuchsia-100 backdrop-blur transition hover:bg-fuchsia-300/20"
            >
              <Sparkles className="h-4 w-4" />
              {translate(t, "creatorProfileManageProfile", "Gerenciar perfil")}
            </Link>
          ) : null}
        </div>

        <section className="mt-8 grid gap-10 lg:grid-cols-[330px_minmax(0,1fr)] lg:items-center">
          <div className="flex justify-center lg:justify-start">
            {creatorForCard ? (
              <div className="relative w-fit scale-[1.14] py-6 sm:scale-[1.2] lg:scale-[1.16]">
                <div className="pointer-events-none absolute -inset-8 -z-10 rounded-[3rem] bg-[radial-gradient(circle,rgba(34,211,238,0.2),transparent_64%)] blur-2xl" />
                <CreatorCard
                  key={`${creatorForCard.id}-${creatorForCard.rarity}`}
                  creator={creatorForCard}
                  onClick={() => undefined}
                />
              </div>
            ) : null}
          </div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-full border border-cyan-300/25 bg-cyan-300/10 px-3 py-1 text-xs font-black uppercase tracking-[0.24em] text-cyan-100 backdrop-blur">
                {translate(t, "creatorProfilePublicProfile", "Perfil público")}
              </span>

              {isLive ? (
                <span className="inline-flex items-center gap-2 rounded-full border border-red-300/30 bg-red-500/15 px-3 py-1 text-xs font-black uppercase tracking-[0.22em] text-red-100 shadow-lg shadow-red-500/10">
                  <Radio className="h-3.5 w-3.5 animate-pulse" />
                  {translate(t, "creatorProfileLiveNow", "Ao vivo agora")}
                </span>
              ) : (
                <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-black uppercase tracking-[0.22em] text-white/45 backdrop-blur">
                  <WifiOff className="h-3.5 w-3.5" />
                  {translate(t, "creatorProfileOffline", "Offline")}
                </span>
              )}

              {profile.is_verified ? (
                <span className="inline-flex items-center gap-2 rounded-full border border-yellow-300/25 bg-yellow-300/10 px-3 py-1 text-xs font-black uppercase tracking-[0.22em] text-yellow-100 backdrop-blur">
                  <ShieldCheck className="h-3.5 w-3.5" />
                  {translate(t, "creatorProfileVerified", "Verificado")}
                </span>
              ) : null}
            </div>

            {isEditing && editDraft ? (
              <div className="mt-6 grid gap-4">
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                    {translate(
                      t,
                      "creatorProfileEditNickname",
                      "Nome de exibição",
                    )}
                  </span>
                  <input
                    value={editDraft.nickname}
                    onChange={(event) =>
                      handleEditDraftChange("nickname", event.target.value)
                    }
                    className="mt-2 w-full rounded-[1.2rem] border border-cyan-300/20 bg-black/35 px-4 py-3 text-3xl font-black tracking-[-0.04em] text-white outline-none transition focus:border-cyan-300/55 md:text-5xl"
                  />
                </label>

                <div className="grid gap-4 md:grid-cols-2">
                  <label className="block">
                    <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                      {translate(t, "creatorProfileEditTitle", "Título")}
                    </span>
                    <input
                      value={editDraft.title}
                      onChange={(event) =>
                        handleEditDraftChange("title", event.target.value)
                      }
                      className="mt-2 w-full rounded-[1.2rem] border border-white/10 bg-black/35 px-4 py-3 text-base font-semibold text-cyan-100 outline-none transition focus:border-cyan-300/45"
                    />
                  </label>

                  <label className="block">
                    <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                      {translate(t, "creatorProfileEditCategory", "Categoria")}
                    </span>
                    <input
                      value={editDraft.category}
                      onChange={(event) =>
                        handleEditDraftChange("category", event.target.value)
                      }
                      className="mt-2 w-full rounded-[1.2rem] border border-white/10 bg-black/35 px-4 py-3 text-base font-semibold text-white/85 outline-none transition focus:border-cyan-300/45"
                    />
                  </label>
                </div>

                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                    {translate(t, "creatorProfileEditBio", "Bio curta")}
                  </span>
                  <textarea
                    value={editDraft.bio}
                    onChange={(event) =>
                      handleEditDraftChange("bio", event.target.value)
                    }
                    rows={3}
                    className="mt-2 w-full resize-none rounded-[1.2rem] border border-white/10 bg-black/35 px-4 py-3 text-base leading-7 text-white/80 outline-none transition focus:border-cyan-300/45"
                  />
                </label>
              </div>
            ) : (
              <>
                <h1 className="mt-6 max-w-4xl text-5xl font-black tracking-[-0.06em] text-white drop-shadow-[0_0_32px_rgba(34,211,238,0.16)] md:text-7xl">
                  {nickname}
                </h1>

                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <p className="text-lg font-semibold text-cyan-100/90 md:text-2xl">
                    {title}
                  </p>
                  <span className="text-sm font-bold text-white/38">
                    @{profile.username}
                  </span>
                </div>

                <p className="mt-6 max-w-3xl text-base leading-8 text-white/68 md:text-lg">
                  {bio}
                </p>
              </>
            )}

            <div className="mt-7 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleFollow}
                disabled={followLoading}
                className="inline-flex items-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/10 px-5 py-3 text-sm font-black text-cyan-100 transition hover:bg-cyan-300/20 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {followLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : isFollowing ? (
                  <UserCheck className="h-4 w-4" />
                ) : (
                  <UserPlus className="h-4 w-4" />
                )}
                {isFollowing
                  ? translate(t, "creatorPopupFollowing", "Seguindo")
                  : translate(t, "creatorPopupFollow", "Seguir")}
              </button>

              <button
                type="button"
                onClick={copyProfileLink}
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-5 py-3 text-sm font-black text-white/70 transition hover:border-cyan-300/25 hover:text-cyan-100"
              >
                <Share2 className="h-4 w-4" />
                {profileLinkCopied
                  ? translate(
                      t,
                      "creatorProfileProfileLinkCopied",
                      "Link copiado",
                    )
                  : translate(
                      t,
                      "creatorProfileCopyProfileLink",
                      "Copiar link do perfil",
                    )}
              </button>

              {!isEditing && isProfileClaimable ? (
                <button
                  type="button"
                  onClick={() =>
                    router.push(
                      `/?creator=${encodeURIComponent(profile.username)}&claim=1`,
                    )
                  }
                  className="inline-flex items-center gap-2 rounded-full border border-yellow-300/25 bg-yellow-300/10 px-5 py-3 text-sm font-black text-yellow-100 transition hover:bg-yellow-300/20"
                >
                  <ShieldCheck className="h-4 w-4" />
                  {translate(
                    t,
                    "creatorPopupClaimProfileBadge",
                    "Reivindicar Perfil",
                  )}
                </button>
              ) : null}
            </div>

            {isEditing && editDraft ? (
              <div className="mt-7 grid gap-4">
                <label className="block">
                  <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                    {translate(t, "creatorProfileEditTags", "Tags")}
                  </span>
                  <input
                    value={editDraft.tagsText}
                    onChange={(event) =>
                      handleEditDraftChange("tagsText", event.target.value)
                    }
                    placeholder="Streamer, MMORPG, Black Desert"
                    className="mt-2 w-full rounded-[1.2rem] border border-cyan-300/20 bg-black/35 px-4 py-3 text-sm font-semibold text-cyan-100 outline-none transition placeholder:text-white/25 focus:border-cyan-300/45"
                  />
                </label>
              </div>
            ) : visibleTags.length > 0 ? (
              <div className="mt-7 flex flex-wrap gap-3">
                {visibleTags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-2xl border border-cyan-300/15 bg-cyan-300/[0.07] px-4 py-2 text-sm font-bold text-cyan-100/85 backdrop-blur"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            ) : null}

            <div className="mt-8 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <div className="rounded-[1.4rem] border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl">
                <div className="flex items-center gap-2 text-white/40">
                  <Eye className="h-4 w-4" />
                  <p className="text-[10px] font-black uppercase tracking-[0.22em]">
                    {translate(t, "creatorProfileViews", "Visualizações")}
                  </p>
                </div>
                <p className="mt-3 text-3xl font-black">
                  {formatNumber(stats.views)}
                </p>
              </div>

              <div className="rounded-[1.4rem] border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl">
                <div className="flex items-center gap-2 text-white/40">
                  <UserCheck className="h-4 w-4" />
                  <p className="text-[10px] font-black uppercase tracking-[0.22em]">
                    {translate(t, "creatorProfileFollowers", "Seguidores")}
                  </p>
                </div>
                <p className="mt-3 text-3xl font-black">
                  {formatNumber(stats.followers)}
                </p>
              </div>

              <div className="rounded-[1.4rem] border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl">
                <div className="flex items-center gap-2 text-white/40">
                  <Globe2 className="h-4 w-4" />
                  <p className="text-[10px] font-black uppercase tracking-[0.22em]">
                    {translate(
                      t,
                      "creatorProfileExternalReach",
                      "Alcance externo",
                    )}
                  </p>
                </div>
                <p className="mt-3 text-3xl font-black">
                  {liveStatusLoading ? "..." : formatNumber(externalReach)}
                </p>
              </div>

              <div className="rounded-[1.4rem] border border-white/10 bg-white/[0.04] p-5 backdrop-blur-xl">
                <div className="flex items-center gap-2 text-white/40">
                  <Share2 className="h-4 w-4" />
                  <p className="text-[10px] font-black uppercase tracking-[0.22em]">
                    {translate(t, "creatorProfileShares", "Compartilhamentos")}
                  </p>
                </div>
                <p className="mt-3 text-3xl font-black">
                  {formatNumber(stats.shares)}
                </p>
              </div>
            </div>
          </div>
        </section>

        {heroLiveStatus ? (
          <button
            type="button"
            onClick={() => {
              if (livePlatformItems.length > 1) {
                setLivePlatformsOpen(true);
                return;
              }

              window.open(
                heroLiveStatus.url || "#",
                "_blank",
                "noopener,noreferrer",
              );
            }}
            className="mt-8 flex w-full items-center gap-3 rounded-[1.6rem] border border-red-300/20 bg-red-500/10 px-5 py-4 text-left text-sm font-bold text-red-50 backdrop-blur-xl transition hover:bg-red-500/15"
          >
            <Radio className="h-5 w-5 animate-pulse" />
            <span className="line-clamp-1">
              {livePlatformItems.length > 1
                ? translate(
                    t,
                    "creatorProfileChooseLivePlatform",
                    "Este criador está ao vivo em mais de uma plataforma. Escolha onde assistir.",
                  )
                : heroLiveStatus.title ||
                  translate(
                    t,
                    "creatorProfileLiveFallbackTitle",
                    "Live em andamento",
                  )}
            </span>
            {heroLiveStatus.viewerCount ? (
              <span className="ml-auto whitespace-nowrap text-red-100/70">
                {formatNumber(heroLiveStatus.viewerCount)}{" "}
                {translate(t, "creatorProfileViewers", "assistindo")}
              </span>
            ) : null}
          </button>
        ) : null}

        <section className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
          <div className="space-y-6">
            <article className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-2xl shadow-black/20 backdrop-blur-xl md:p-8">
              <div className="flex items-center gap-3">
                <Sparkles className="h-5 w-5 text-cyan-200" />
                <h2 className="text-2xl font-black tracking-tight">
                  {translate(t, "creatorProfileAboutTitle", "Sobre o criador")}
                </h2>
              </div>

              {isEditing && editDraft ? (
                <textarea
                  value={editDraft.description}
                  onChange={(event) =>
                    handleEditDraftChange("description", event.target.value)
                  }
                  rows={7}
                  className="mt-5 w-full resize-none rounded-[1.2rem] border border-white/10 bg-black/35 px-4 py-3 text-base leading-8 text-white/75 outline-none transition focus:border-cyan-300/45"
                />
              ) : (
                <p className="mt-5 whitespace-pre-line text-base leading-8 text-white/68">
                  {description}
                </p>
              )}
            </article>

            {isEditing && editDraft ? (
              <article className="rounded-[2rem] border border-cyan-300/15 bg-cyan-300/[0.035] p-6 shadow-2xl shadow-cyan-500/10 backdrop-blur-xl md:p-8">
                <div className="flex items-center gap-3">
                  <Globe2 className="h-5 w-5 text-cyan-200" />
                  <h2 className="text-2xl font-black tracking-tight">
                    {translate(
                      t,
                      "creatorProfileEditMediaTitle",
                      "Mídia e links",
                    )}
                  </h2>
                </div>

                <div className="mt-5 grid gap-4 md:grid-cols-2">
                  <label className="block">
                    <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                      {translate(
                        t,
                        "creatorProfileEditAvatarUrl",
                        "URL do avatar",
                      )}
                    </span>
                    <input
                      value={editDraft.avatarUrl}
                      onChange={(event) =>
                        handleEditDraftChange("avatarUrl", event.target.value)
                      }
                      className="mt-2 w-full rounded-[1.2rem] border border-white/10 bg-black/35 px-4 py-3 text-sm text-white/80 outline-none transition focus:border-cyan-300/45"
                    />
                  </label>

                  <label className="block">
                    <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                      {translate(
                        t,
                        "creatorProfileEditBannerUrl",
                        "URL do banner",
                      )}
                    </span>
                    <input
                      value={editDraft.bannerUrl}
                      onChange={(event) =>
                        handleEditDraftChange("bannerUrl", event.target.value)
                      }
                      className="mt-2 w-full rounded-[1.2rem] border border-white/10 bg-black/35 px-4 py-3 text-sm text-white/80 outline-none transition focus:border-cyan-300/45"
                    />
                  </label>
                </div>

                <div className="mt-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="text-xs font-black uppercase tracking-[0.22em] text-cyan-100/70">
                      {translate(
                        t,
                        "creatorProfileEditSocialLinks",
                        "Links sociais",
                      )}
                    </span>
                    <button
                      type="button"
                      onClick={handleAddEditSocialLink}
                      className="inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-2 text-xs font-black uppercase tracking-[0.18em] text-cyan-100 transition hover:bg-cyan-300/15"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      {translate(
                        t,
                        "creatorProfileEditAddSocialLink",
                        "Adicionar link",
                      )}
                    </button>
                  </div>

                  <div className="mt-3 grid gap-3">
                    {getEditSocialLinkRows(editDraft.socialLinksText).map(
                      (social, index) => (
                        <div
                          key={`social-link-${index}`}
                          className="grid gap-3 rounded-[1.2rem] border border-white/10 bg-black/25 p-3 md:grid-cols-[180px_minmax(0,1fr)_auto]"
                        >
                          <select
                            value={social.platform || "link"}
                            onChange={(event) =>
                              handleEditSocialLinkChange(
                                index,
                                "platform",
                                event.target.value,
                              )
                            }
                            className="rounded-[1rem] border border-white/10 bg-black/35 px-3 py-3 text-sm font-bold text-cyan-100 outline-none transition focus:border-cyan-300/45"
                          >
                            {SOCIAL_PLATFORM_OPTIONS.map((option) => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </select>

                          <input
                            value={social.url}
                            onChange={(event) =>
                              handleEditSocialLinkChange(
                                index,
                                "url",
                                event.target.value,
                              )
                            }
                            placeholder="https://..."
                            className="rounded-[1rem] border border-white/10 bg-black/35 px-4 py-3 text-sm text-white/80 outline-none transition placeholder:text-white/25 focus:border-cyan-300/45"
                          />

                          <button
                            type="button"
                            onClick={() => handleRemoveEditSocialLink(index)}
                            className="inline-flex items-center justify-center rounded-[1rem] border border-red-300/15 bg-red-500/10 px-4 py-3 text-red-100 transition hover:bg-red-500/15"
                            aria-label={translate(
                              t,
                              "creatorProfileEditRemoveSocialLink",
                              "Remover link",
                            )}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ),
                    )}
                  </div>
                </div>
              </article>
            ) : null}

            <article className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-2xl shadow-black/20 backdrop-blur-xl md:p-8">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <PlayCircle className="h-5 w-5 text-fuchsia-200" />
                  <h2 className="text-2xl font-black tracking-tight">
                    {translate(
                      t,
                      "creatorProfileFeaturedClips",
                      "Clipes em destaque",
                    )}
                  </h2>
                </div>

                {clipsLoading ? (
                  <span className="inline-flex items-center gap-2 text-sm font-bold text-white/45">
                    <Loader2 className="h-4 w-4 animate-spin text-cyan-100" />
                    {translate(
                      t,
                      "creatorProfileLoadingClips",
                      "Carregando clipes...",
                    )}
                  </span>
                ) : null}
              </div>

              {clipsLoading ? (
                <div className="mt-6 rounded-[1.4rem] border border-white/10 bg-white/[0.04] p-5 text-sm font-bold text-white/50">
                  {translate(
                    t,
                    "creatorProfileLoadingClips",
                    "Carregando clipes...",
                  )}
                </div>
              ) : clips.length > 0 ? (
                <div className="mt-6 space-y-7">
                  {clipPlatformSections.map(([platform, platformClips]) => (
                    <section key={platform}>
                      <div className="mb-3 flex items-center justify-between gap-3">
                        <p className="text-xs font-black uppercase tracking-[0.24em] text-cyan-100/60">
                          {getPlatformLabel(platform)}
                        </p>
                        <span className="text-xs font-bold text-white/35">
                          {platformClips.length}{" "}
                          {platformClips.length === 1
                            ? translate(t, "creatorProfileClipSingular", "clip")
                            : translate(t, "creatorProfileClipPlural", "clips")}
                        </span>
                      </div>

                      <div className="relative">
                        <button
                          type="button"
                          onClick={() => {
                            document
                              .getElementById(
                                `creator-profile-clips-${platform}`,
                              )
                              ?.scrollBy({ left: -380, behavior: "smooth" });
                          }}
                          className="absolute left-2 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/10 bg-black/75 text-white/75 shadow-2xl backdrop-blur transition hover:border-cyan-300/30 hover:bg-cyan-300/15 hover:text-cyan-100 sm:flex"
                          aria-label={translate(
                            t,
                            "creatorProfilePreviousClips",
                            "Clipes anteriores",
                          )}
                        >
                          <ChevronLeft className="h-5 w-5" />
                        </button>

                        <div
                          id={`creator-profile-clips-${platform}`}
                          className="flex snap-x gap-4 overflow-x-auto scroll-smooth pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
                        >
                          {platformClips.map((clip) => {
                            const thumbnail =
                              clip.thumbnailUrl || clip.thumbnail_url;
                            const viewCount =
                              clip.viewCount ?? clip.view_count ?? 0;
                            const clipHref = getSafeClipUrl(clip, socialLinks);

                            return (
                              <a
                                key={clip.id}
                                href={clipHref}
                                target="_blank"
                                rel="noreferrer"
                                className="group w-[280px] shrink-0 snap-start overflow-hidden rounded-[1.4rem] border border-white/10 bg-black/30 transition hover:border-cyan-300/30 hover:bg-cyan-300/[0.04] sm:w-[340px]"
                              >
                                <div className="aspect-video bg-white/[0.04]">
                                  {thumbnail ? (
                                    <img
                                      src={thumbnail}
                                      alt={clip.title}
                                      className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                                    />
                                  ) : (
                                    <div className="flex h-full w-full items-center justify-center text-white/30">
                                      <PlayCircle className="h-10 w-10" />
                                    </div>
                                  )}
                                </div>

                                <div className="p-4">
                                  <div className="flex items-center justify-between gap-3">
                                    <p className="text-xs font-black uppercase tracking-[0.24em] text-cyan-100/60">
                                      {getPlatformLabel(clip.platform)}
                                    </p>

                                    {viewCount > 0 ? (
                                      <span className="text-xs font-bold text-white/40">
                                        {formatNumber(viewCount)}
                                      </span>
                                    ) : null}
                                  </div>

                                  <h3 className="mt-2 line-clamp-2 text-sm font-black leading-6 text-white">
                                    {clip.title}
                                  </h3>
                                </div>
                              </a>
                            );
                          })}
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            document
                              .getElementById(
                                `creator-profile-clips-${platform}`,
                              )
                              ?.scrollBy({ left: 380, behavior: "smooth" });
                          }}
                          className="absolute right-2 top-1/2 z-20 hidden h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full border border-white/10 bg-black/75 text-white/75 shadow-2xl backdrop-blur transition hover:border-cyan-300/30 hover:bg-cyan-300/15 hover:text-cyan-100 sm:flex"
                          aria-label={translate(
                            t,
                            "creatorProfileNextClips",
                            "Próximos clipes",
                          )}
                        >
                          <ChevronRight className="h-5 w-5" />
                        </button>
                      </div>
                    </section>
                  ))}
                </div>
              ) : (
                <p className="mt-5 text-sm leading-7 text-white/50">
                  {translate(
                    t,
                    "creatorProfileNoClips",
                    "Este criador ainda não possui clipes públicos em destaque.",
                  )}
                </p>
              )}
            </article>
          </div>

          <aside className="space-y-6">
            {platformCounters.length > 0 ? (
              <article className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-2xl shadow-black/20 backdrop-blur-xl">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.24em] text-cyan-100/55">
                      {translate(
                        t,
                        "creatorProfilePlatformsTitle",
                        "Plataformas",
                      )}
                    </p>
                    <h2 className="mt-2 text-xl font-black tracking-tight">
                      {translate(
                        t,
                        "creatorProfileExternalAudience",
                        "Audiência externa",
                      )}
                    </h2>
                  </div>

                  {liveStatusLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin text-cyan-100/70" />
                  ) : null}
                </div>

                <div className="mt-5 space-y-3">
                  {platformCounters.map((platform) => {
                    const platformContent = (
                      <>
                        <div className="flex items-center justify-between gap-3">
                          <p className="text-sm font-black uppercase tracking-[0.22em] text-white/55">
                            {platform.label}
                          </p>

                          {platform.isLive ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-red-500/15 px-2 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-red-100">
                              <Radio className="h-3 w-3 animate-pulse" />
                              Live
                            </span>
                          ) : null}
                        </div>

                        <p className="mt-3 text-3xl font-black">
                          {formatNumber(platform.value)}
                        </p>
                        <p className="mt-1 text-xs font-semibold text-white/45">
                          {platform.suffix}
                        </p>
                      </>
                    );

                    if (
                      platform.key === "youtube" &&
                      visibleYoutubeChannels.length > 1
                    ) {
                      return (
                        <button
                          key={platform.key}
                          type="button"
                          onClick={() => setYoutubeChannelsOpen(true)}
                          className="block w-full rounded-[1.3rem] border border-white/10 bg-black/25 p-4 text-left transition hover:border-cyan-300/25 hover:bg-cyan-300/[0.06]"
                        >
                          {platformContent}
                        </button>
                      );
                    }

                    return (
                      <a
                        key={platform.key}
                        href={platform.url || "#"}
                        target="_blank"
                        rel="noreferrer"
                        className="block rounded-[1.3rem] border border-white/10 bg-black/25 p-4 transition hover:border-cyan-300/25 hover:bg-cyan-300/[0.06]"
                      >
                        {platformContent}
                      </a>
                    );
                  })}
                </div>
              </article>
            ) : null}

            <article className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-2xl shadow-black/20 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Globe2 className="h-5 w-5 text-cyan-200" />
                <h2 className="text-xl font-black tracking-tight">
                  {translate(t, "creatorProfileSocialLinks", "Redes sociais")}
                </h2>
              </div>

              {socialLinks.length > 0 ? (
                <div className="mt-5 space-y-3">
                  {[
                    ...socialLinks.filter(
                      (social) => social.platform.toLowerCase() !== "youtube",
                    ),
                    ...(visibleYoutubeChannels.length > 0
                      ? [
                          {
                            platform: "youtube",
                            url: visibleYoutubeChannels[0].url,
                          },
                        ]
                      : []),
                  ].map((social) => {
                    const isYoutube =
                      social.platform.toLowerCase() === "youtube";

                    if (isYoutube) {
                      return (
                        <button
                          key="youtube-channels"
                          type="button"
                          onClick={() => {
                            if (visibleYoutubeChannels.length > 1) {
                              setYoutubeChannelsOpen(true);
                              return;
                            }

                            window.open(
                              social.url,
                              "_blank",
                              "noopener,noreferrer",
                            );
                          }}
                          className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-left text-sm font-bold text-white/75 transition hover:border-cyan-300/30 hover:text-cyan-100"
                        >
                          <span>
                            {visibleYoutubeChannels.length > 1
                              ? `YouTube (${visibleYoutubeChannels.length})`
                              : "YouTube"}
                          </span>

                          <span className="ml-auto mr-3 text-xs font-black text-cyan-100/70">
                            {youtubeExternalReach > 0
                              ? `${formatNumber(youtubeExternalReach)} ${translate(
                                  t,
                                  "creatorProfileSubscribers",
                                  "inscritos",
                                )}`
                              : null}
                          </span>

                          <ExternalLink className="h-4 w-4 shrink-0" />
                        </button>
                      );
                    }

                    return (
                      <a
                        key={`${social.platform}-${social.url}`}
                        href={social.url}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm font-bold text-white/75 transition hover:border-cyan-300/30 hover:text-cyan-100"
                      >
                        <span>{getPlatformLabel(social.platform)}</span>

                        {(() => {
                          const normalizedPlatform =
                            social.platform.toLowerCase();
                          const platformStatus = getPlatformLiveStatus(
                            liveStatus,
                            normalizedPlatform,
                          );
                          const platformCount =
                            getTrustedLiveStatusExternalCount(
                              normalizedPlatform,
                              platformStatus,
                            );
                          const platformSuffix =
                            normalizedPlatform === "discord"
                              ? "membros"
                              : translate(
                                  t,
                                  "creatorProfileFollowersShort",
                                  "seguidores",
                                );

                          return platformCount > 0 ? (
                            <span className="ml-auto mr-3 text-xs font-black text-cyan-100/70">
                              {formatNumber(platformCount)} {platformSuffix}
                            </span>
                          ) : null;
                        })()}

                        <ExternalLink className="h-4 w-4 shrink-0" />
                      </a>
                    );
                  })}
                </div>
              ) : (
                <p className="mt-5 text-sm leading-7 text-white/50">
                  {translate(
                    t,
                    "creatorProfileNoSocialLinks",
                    "As redes sociais deste criador ainda não foram adicionadas.",
                  )}
                </p>
              )}
            </article>

            <article className="rounded-[2rem] border border-white/10 bg-white/[0.04] p-6 shadow-2xl shadow-black/20 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <Users className="h-5 w-5 text-fuchsia-200" />
                <h2 className="text-xl font-black tracking-tight">
                  {translate(t, "creatorProfileCardStats", "Carta do criador")}
                </h2>
              </div>

              <div className="mt-5 space-y-3 text-sm">
                <div className="flex items-center justify-between rounded-2xl bg-white/[0.04] px-4 py-3">
                  <span className="text-white/45">
                    {translate(t, "creatorProfileCardRarity", "Raridade")}
                  </span>
                  <strong>{getRarityLabel(rarity)}</strong>
                </div>

                <div className="flex items-center justify-between rounded-2xl bg-white/[0.04] px-4 py-3">
                  <span className="text-white/45">
                    {translate(t, "creatorProfileCardRank", "Rank")}
                  </span>
                  <strong>
                    {card?.rank ||
                      translate(t, "creatorProfileDefaultRank", "Bronze")}
                  </strong>
                </div>

                <div className="flex items-center justify-between rounded-2xl bg-white/[0.04] px-4 py-3">
                  <span className="text-white/45">
                    {translate(t, "creatorProfileCardLevel", "Nível")}
                  </span>
                  <strong>{card?.level || 1}</strong>
                </div>

                <div className="flex items-center justify-between rounded-2xl bg-white/[0.04] px-4 py-3">
                  <span className="text-white/45">
                    {translate(t, "creatorProfileCardPower", "Poder")}
                  </span>
                  <strong>{formatNumber(card?.power_score || 0)}</strong>
                </div>
              </div>

              <button
                type="button"
                onClick={copyProfileLink}
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-cyan-300/25 bg-cyan-300/10 px-4 py-3 text-sm font-black text-cyan-100 transition hover:bg-cyan-300/20"
              >
                <Share2 className="h-4 w-4" />
                {profileLinkCopied
                  ? translate(
                      t,
                      "creatorProfileProfileLinkCopied",
                      "Link copiado",
                    )
                  : translate(
                      t,
                      "creatorProfileCopyProfileLink",
                      "Copiar link do perfil",
                    )}
              </button>
            </article>
          </aside>
        </section>
      </div>

      {livePlatformsOpen ? (
        <div className="fixed inset-0 z-[130] flex items-center justify-center bg-black/80 px-4 py-6 sm:px-6">
          <button
            type="button"
            className="absolute inset-0"
            onClick={() => setLivePlatformsOpen(false)}
            aria-label={translate(
              t,
              "creatorProfileCloseLivePlatforms",
              "Fechar plataformas ao vivo",
            )}
          />

          <div className="relative w-[min(92vw,760px)] rounded-[28px] border border-white/15 bg-zinc-950/95 p-5 text-white shadow-[0_0_90px_rgba(0,0,0,0.95)] sm:p-6">
            <div className="pointer-events-none absolute -left-24 -top-24 h-48 w-48 rounded-full bg-red-500/20 blur-[80px]" />
            <div className="pointer-events-none absolute -bottom-24 -right-24 h-48 w-48 rounded-full bg-cyan-500/20 blur-[80px]" />

            <div className="relative z-10">
              <p className="text-xs font-black uppercase tracking-[0.3em] text-red-200">
                {translate(t, "creatorProfileLiveNow", "Ao vivo agora")}
              </p>

              <h3 className="mt-3 text-xl font-black sm:text-2xl">
                {translate(
                  t,
                  "creatorProfileLivePlatformsTitle",
                  "Escolha onde assistir",
                )}
              </h3>

              <p className="mt-2 text-sm text-white/45">
                {translate(
                  t,
                  "creatorProfileLivePlatformsDescription",
                  "Este criador está online em mais de uma plataforma.",
                )}
              </p>

              <div className="mt-5 grid gap-3">
                {livePlatformItems.map((item) => (
                  <a
                    key={item.key}
                    href={item.status?.url || item.fallbackUrl || "#"}
                    target="_blank"
                    rel="noreferrer"
                    onClick={() => setLivePlatformsOpen(false)}
                    className="group flex min-w-0 items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-3 transition hover:border-red-300/30 hover:bg-red-300/10"
                  >
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-red-500/15 text-xs font-black text-red-100">
                      <Radio className="h-5 w-5 animate-pulse" />
                    </div>

                    <div className="min-w-0 flex-1 pr-2">
                      <p className="font-black text-white">{item.label}</p>
                      <p className="break-words text-sm leading-snug text-white/45">
                        {item.status?.title ||
                          translate(
                            t,
                            "creatorProfileLiveFallbackTitle",
                            "Live em andamento",
                          )}
                      </p>
                    </div>

                    {item.status?.viewerCount ? (
                      <span className="hidden shrink-0 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-sm font-bold text-red-100/70 sm:inline-flex">
                        {formatNumber(item.status.viewerCount)}
                      </span>
                    ) : null}
                  </a>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setLivePlatformsOpen(false)}
                className="mt-5 w-full rounded-full border border-white/10 bg-white/[0.04] px-5 py-3 text-sm text-white/70 transition hover:bg-white/[0.08]"
              >
                {translate(t, "creatorProfileClose", "Fechar")}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {youtubeChannelsOpen ? (
        <div className="fixed inset-0 z-[130] flex items-center justify-center bg-black/75 p-4">
          <button
            type="button"
            className="absolute inset-0"
            onClick={() => setYoutubeChannelsOpen(false)}
            aria-label={translate(
              t,
              "creatorPopupCloseYoutubeChannels",
              "Fechar canais do YouTube",
            )}
          />

          <div className="relative w-full max-w-lg overflow-hidden rounded-[28px] border border-white/15 bg-zinc-950 p-5 text-white shadow-[0_0_70px_rgba(0,0,0,0.9)] sm:p-6">
            <div className="absolute -left-20 -top-20 h-40 w-40 rounded-full bg-red-500/20 blur-[70px]" />
            <div className="absolute -bottom-20 -right-20 h-40 w-40 rounded-full bg-cyan-500/20 blur-[70px]" />

            <div className="relative z-10">
              <p className="text-xs font-black uppercase tracking-[0.3em] text-cyan-200">
                YouTube
              </p>

              <h3 className="mt-3 text-xl font-black sm:text-2xl">
                {translate(
                  t,
                  "creatorPopupYoutubeChannelsTitle",
                  "Canais do YouTube",
                )}
              </h3>

              <p className="mt-2 text-sm text-white/45">
                {translate(
                  t,
                  "creatorPopupYoutubeChannelsDescription",
                  "Escolha qual canal você quer abrir.",
                )}
              </p>

              <div className="mt-5 grid gap-3">
                {youtubeChannelItems.map((channel, index) => (
                  <a
                    key={`${channel.url}-${index}`}
                    href={channel.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-3 transition hover:border-cyan-300/30 hover:bg-cyan-300/10"
                  >
                    {channel.thumbnail ? (
                      <img
                        src={channel.thumbnail}
                        alt={channel.title}
                        className="h-12 w-12 shrink-0 rounded-xl object-cover"
                      />
                    ) : (
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-cyan-300/10 text-xs font-bold text-cyan-100">
                        YT
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <p className="truncate font-bold text-white">
                        {channel.title}
                      </p>

                      <p className="text-sm text-white/45">
                        {formatNumber(channel.subscriberCount)}{" "}
                        {translate(
                          t,
                          "creatorPopupYoutubeSubscribers",
                          "inscritos",
                        )}
                      </p>
                    </div>
                  </a>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setYoutubeChannelsOpen(false)}
                className="mt-5 w-full rounded-full border border-white/10 bg-white/[0.04] px-5 py-3 text-sm text-white/70 transition hover:bg-white/[0.08]"
              >
                {translate(t, "creatorProfileClose", "Fechar")}
              </button>
            </div>
          </div>
        </div>
      ) : null}
      {isEditing && canManageProfile ? (
        <div className="fixed inset-x-0 bottom-4 z-[80] px-4 sm:bottom-6">
          <div className="mx-auto flex max-w-3xl flex-col gap-4 rounded-[1.7rem] border border-cyan-300/20 bg-[#020617]/90 p-4 shadow-2xl shadow-cyan-500/20 backdrop-blur-2xl sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-black text-white">
                {translate(
                  t,
                  "creatorProfileUnsavedChanges",
                  "Alterações não salvas",
                )}
              </p>
              <p className="mt-1 text-xs leading-5 text-white/50">
                {translate(
                  t,
                  "creatorProfileUnsavedChangesDescription",
                  "Salve para publicar as mudanças no perfil ou cancele para voltar ao modo de visualização.",
                )}
              </p>
              {profileSaveError ? (
                <p className="mt-2 text-xs font-bold text-red-200">
                  {profileSaveError}
                </p>
              ) : null}
            </div>

            <div className="flex shrink-0 gap-3">
              <button
                type="button"
                onClick={handleCancelEditMode}
                disabled={isSavingProfile}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-5 py-3 text-sm font-black text-white/70 transition hover:bg-white/[0.08] disabled:cursor-not-allowed disabled:opacity-60"
              >
                {translate(t, "creatorProfileCancelEdit", "Cancelar")}
              </button>

              <button
                type="button"
                onClick={handleSaveProfileEdit}
                disabled={isSavingProfile}
                className="inline-flex items-center justify-center gap-2 rounded-full border border-cyan-300/25 bg-cyan-300/15 px-5 py-3 text-sm font-black text-cyan-50 shadow-lg shadow-cyan-500/10 transition hover:bg-cyan-300/25 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {isSavingProfile ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : null}
                {translate(t, "creatorProfileSaveEdit", "Salvar")}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  );
}
